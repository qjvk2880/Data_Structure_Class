void find_path(char *, char *);
